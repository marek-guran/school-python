def otoc(retazec):
    if len(retazec) <= 1:
        return retazec
    prva = otoc(retazec[:len(retazec)//2])
    druha = otoc(retazec[len(retazec)//2:])
    return druha + prva

print(otoc('Bratislava'))
print(otoc('Bratislava'*100))
print(otoc('Bratislava'*200))
r = otoc('Bratislava'*100000)
print(len(r),r == ('Bratislava'*100000)[::-1])                                                                                                                                                                                                
