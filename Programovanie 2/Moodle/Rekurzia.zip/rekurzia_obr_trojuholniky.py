def trojuholniky(n, a):
    if n > 0:
        for i in range(3):
            t.fd(a)
            t.rt(120)
            trojuholniky(n-1, a/2)

import turtle
turtle.delay(0)
t = turtle.Turtle()
t.speed(0)
t.rt(60)
trojuholniky(6, 400)
