#Rekurzivna spirala 
def spir(d):
    if d > 100:
        t.pencolor('red') # a skonci
    else:
        t.fd(d)
        t.lt(60);
        spir(d + 3)
        t.fd(S)
        t.lt(60)

import turtle
turtle.delay(0)
t = turtle.Turtle()
t.speed(0)
spir(1)
